package com.ibm.trainings.constant;

public class TrainingConstant {
	public static final String TRAINGS_API = "trainings";
	public static final String API_ERROR_MSG_SEARCH_START_END_DATE_ERROR = "The searchStartDate should be <= searchEndDate";
	public static final String SQL_DATE_FORMAT = "YYYY-MM-DD";
}
