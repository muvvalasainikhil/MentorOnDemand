package com.ibm.payments.model;

public class PaymentResponse {

}
